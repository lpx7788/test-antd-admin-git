import Vue from 'vue'
// import { Button,Menu,Icon,Layout } from 'ant-design-vue'

// Vue.component(Button.name, Button)
// Vue.component(Icon.name, Icon)
// Vue.component(Layout.name, Layout)

// Vue.use(Menu);