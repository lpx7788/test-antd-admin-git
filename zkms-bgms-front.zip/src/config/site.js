/**
 * 全局配置文件
 */
export default {
    title: '商城-后台系统',
    whiteList: ["login", "home", "404"]
};